# Pompom Hold Study

A single-screen, grayscale, low-fi interaction study: a deflated pompom that you **press and hold** to inflate. A ring fills while you hold, the fibers tremble harder and the sound rises, and when the ring completes the pompom pops to full fluff with a burst and a thump.

Part of the Project 2 "Sequential Interactions" set. Intended to sit in a repo beside other studies (e.g. Drag, Flick) and be combined into one connected sequence in Claude Code.

## Run it

- No build step, no package install, no dependencies. It is one self-contained file: `index.html`.
- Open `index.html` directly in a browser, or serve the folder: `python3 -m http.server 8000` then visit `http://localhost:8000`.
- Best viewed on a phone, or a desktop browser in device mode (the stage is capped at 390 x 844 px and centered). Touch, mouse and pen all work (Pointer Events).
- Sound uses the Web Audio API and only starts after the first touch (browser autoplay rule).

## What the study does

The pompom starts small and flat (45 percent size). Pressing and holding on it fills a circular progress ring over about 1.1 seconds. During the hold, the pompom grows toward full size, its fibers shake faster and wider, and a rising whoosh plays. Releasing early cancels: the ring drains back over about 0.5 seconds and the pompom deflates. Holding all the way completes the interaction: the pompom springs to full size with a fiber burst and a strong thump. After that it stays full and further presses do nothing until Reset.

## Main visual and interactive components

| Component | What it is |
|---|---|
| Stage | 390 x 844 max container, light gray `#ececec`, centered on a darker page |
| Pompom | Canvas-drawn fibers (quadratic curves) in three gray tones, with a spring-simulated tip per fiber; size animated by a spring (`puff`) |
| Hold target ring | Faint gray ring around the pompom, plus a pulsing outward ring while idle |
| Progress arc | Dark arc drawn clockwise from the top over the ring as the hold progresses |
| Reset button | Circular button, bottom center (44 px) |
| Sound toggle | Circular speaker button, top right (44 px), `aria-pressed` toggles on/off icon |

## User actions, feedback, states, transitions

**Actions**
- Press and hold on the pompom (within about 0.75 x its radius).
- Release early to cancel.
- Reset button: returns to the deflated start state.
- Sound button: mutes or unmutes all audio.

**States** (`stageN`, `holding`, `p`)
- Idle (`stageN=0`, `p=0`): small pompom, pulsing hint ring.
- Holding (`stageN=0`, `holding=true`, `p` rising 0 to 1): progress arc fills, pompom grows from 45 to 100 percent, fibers shake with amplitude up to 4.5x and faster frequency.
- Cancelled (`p` falling): arc and size ease back to idle.
- Complete (`stageN=1`): full-size pompom, rings hidden, input ignored.
- Muted: gain forced to 0.

**Feedback**
- Visual: progress arc, growing size, intensifying fiber shake, fiber burst on completion (`pulse`).
- Audio: whoosh volume and brightness rise with `p` while holding; strong thump (0.9) at completion.

**Transitions**
- Idle to holding: pointerdown on the pompom.
- Holding to idle: pointerup before `p` reaches 1.
- Holding to complete: `p` reaches 1 (takes about 1.1 s of continuous hold).
- Any state to idle: Reset.

## Where things are implemented (`index.html`)

| Line(s) | What |
|---|---|
| 3-15 | Styles: stage, canvas, buttons, sound on/off icon swap |
| 16-20 | Markup: `#stage`, `<canvas id="c">`, sound button `#snd`, reset button `#rst` |
| 22 | `F` fiber data and `const MODE='hold'` |
| 23-31 | Setup: canvas refs, `fib` fiber objects, body `B`, target `T`, state variables (`stageN`, `holding`, `p`, `puff`), `size()` and `reset()` (starts at `puff=.45` in hold mode) |
| 33-45 | Audio: `initAudio()`, `thump()` |
| 46-58 | Input: `pointerdown` (49-51, hold branch on line 50), release `up()` (53-54), reset (57) and sound toggle (58) |
| 60-99 | Main loop `step()` |
| 62-63 | Hold progress: fills over 1.1 s, completion triggers `stageN=1`, `pulse=1`, thump; drains over 0.5 s when released |
| 64 | Size spring: `puff` follows `.45+.55*p` (or 1 once complete) |
| 65 | Body pinned to home position in hold mode |
| 77-82 | Fiber simulation; `amp` and frequency grow with `p` while holding |
| 83-84 | Audio level and filter follow speed and hold progress |
| 87-91 | Drawing: hint ring, faint ring, progress arc |
| 100 | Start: `size(); requestAnimationFrame(step)` |

## Notes for combining studies

- This file is identical to the Drag and Flick studies except for `<title>` and `const MODE='hold'` (line 22). `MODE` is a switch shared by all three; the Drag and Flick branches (lines 52, 67-74, 92) are present but inactive here.
- Hold is the only variant that uses `stageN`. It is the natural place to hang a sequence: `stageN` flips 0 to 1 on completion, which a wrapper could use as the "step done" event.
- All state is global variables; no storage, network, or external assets are used.
- Visual tokens are the CSS variables on line 4 (`--page`, `--stage`, `--ink`, `--chip`).

## External dependencies and assets

None. No scripts, fonts, images, or network requests. Browser APIs used: Canvas 2D, Pointer Events, Web Audio.
