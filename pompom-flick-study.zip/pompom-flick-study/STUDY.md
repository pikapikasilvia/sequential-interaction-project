# Pompom Flick Study

A single-screen, grayscale, low-fi interaction study: a fluffy pompom you can **flick** across the screen and watch bounce off the walls with soft, fiber-level motion and sound.

Part of the Project 2 "Sequential Interactions" set. Intended to sit in a repo beside other studies (e.g. Hold, Drag) and be combined into one connected sequence in Claude Code.

## Run it

- No build step, no package install, no dependencies. It is one self-contained file: `index.html`.
- Open `index.html` directly in a browser, or serve the folder: `python3 -m http.server 8000` then visit `http://localhost:8000`.
- Best viewed on a phone, or a desktop browser in device mode (the stage is capped at 390 x 844 px and centered). Touch, mouse and pen all work (Pointer Events).
- Sound uses the Web Audio API and only starts after the first touch (browser autoplay rule).

## What the study does

A grayscale pompom (about 900 hand-drawn fiber curves, defined as SVG-style bezier data) sits in the upper-middle of the stage. The user grabs it and throws it. After release it keeps its momentum, slows with friction, and bounces off the stage edges. The fibers lag behind the motion, trail the body, and flare outward on each wall hit. A whoosh sound follows speed; a soft thump plays on grab, release and impact.

## Main visual and interactive components

| Component | What it is |
|---|---|
| Stage | 390 x 844 max container, light gray `#ececec`, centered on a darker page |
| Pompom | Canvas-drawn fibers (quadratic curves) in three gray tones, with a spring-simulated tip per fiber |
| Affordance ring | Pulsing, fading ring around the pompom until the first grab |
| Reset button | Circular button, bottom center (44 px) |
| Sound toggle | Circular speaker button, top right (44 px), `aria-pressed` toggles on/off icon |

## User actions, feedback, states, transitions

**Actions**
- Press on the pompom (within about 0.9 x its radius) to grab it.
- Move while pressed to drag it; the body follows the finger through a stiff spring.
- Release to throw: the release velocity carries on as a flick.
- Reset button: returns the pompom to its start position and clears motion.
- Sound button: mutes or unmutes all audio.

**States**
- Idle (not yet used): pulsing affordance ring is shown.
- Dragging: ring hidden, fibers trail behind, soft thump on grab.
- Flying (after release): velocity decays by friction, speed is capped at 2400 px/s, motion stops below 8 px/s.
- Wall impact: velocity reverses at 60 percent, fibers burst outward (`pulse`), thump volume scales with impact speed.
- Muted: gain forced to 0.

**Feedback**
- Visual: fiber lag from body acceleration, fiber burst on impact, affordance ring until first use.
- Audio: continuous filtered-noise whoosh whose volume and brightness rise with speed; thump on grab, release, impact.

**Transitions**
- Drag to fly: pointer release switches the body from spring-follow to free flight.
- Fly to rest: friction and the 8 px/s cutoff.
- Any state to idle: Reset.

## Where things are implemented (`index.html`)

| Line(s) | What |
|---|---|
| 3-15 | Styles: stage, canvas, buttons, sound on/off icon swap |
| 16-20 | Markup: `#stage`, `<canvas id="c">`, sound button `#snd`, reset button `#rst` |
| 22 | `F` fiber data (start x/y, mid control, end x/y, color, width, opacity) and `const MODE='flick'` |
| 23-31 | Setup: canvas refs, `fib` fiber objects with per-fiber spring stiffness/damping, body `B`, target `T`, state variables, `size()` and `reset()` |
| 33-45 | Audio: `initAudio()` (looping brown-noise buffer, band-pass filter, gain), `thump()` (sine drop plus noise burst) |
| 46-58 | Input: `pointerdown` grab (49-51), `pointermove` drag (52), `up` release (53-54), `clampT()` bounds (56), reset (57) and sound toggle (58) listeners |
| 60-99 | Main loop `step()` |
| 67-68 | Drag physics: spring from body to finger target |
| 69-74 | Flick physics: speed cap, friction (`Math.pow(.35,dt)`), wall bounce, `hit()` for pulse + thump |
| 75-82 | Body acceleration and per-fiber spring simulation (lag, burst) |
| 83-84 | Audio level and filter follow speed |
| 85-99 | Drawing: background, affordance ring (92), fibers |
| 100 | Start: `size(); requestAnimationFrame(step)` |

## Notes for combining studies

- `MODE` (line 22) is a leftover switch. The code also contains `'hold'` and drag-style branches (lines 31, 50, 62-65, 88); they are inactive here but keep Hold and Drag behavior available if the sibling studies share this code.
- All state is global variables; no storage, network, or external assets are used, so the study is safe to embed or wrap as a module.
- To chain studies, the natural hooks are: the `reset()` function (entry state), the wall-hit `hit()` and release `up()` (events), and the `stageN` variable (stage counter, used by the Hold variant).
- Visual tokens are the CSS variables on line 4 (`--page`, `--stage`, `--ink`, `--chip`).

## External dependencies and assets

None. No scripts, fonts, images, or network requests. Browser APIs used: Canvas 2D, Pointer Events, Web Audio.
