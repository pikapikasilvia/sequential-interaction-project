# Pompom Drag Study

A single-screen, grayscale, low-fi interaction study: a fluffy pompom you can **drag** around the stage. It follows your finger through a soft spring, settles where you let go, and its fibers lag and sway behind the motion, with a speed-driven whoosh and soft thumps.

Part of the Project 2 "Sequential Interactions" set. Intended to sit in a repo beside other studies (e.g. Hold, Flick) and be combined into one connected sequence in Claude Code.

## Run it

- No build step, no package install, no dependencies. It is one self-contained file: `index.html`.
- Open `index.html` directly in a browser, or serve the folder: `python3 -m http.server 8000` then visit `http://localhost:8000`.
- Best viewed on a phone, or a desktop browser in device mode (the stage is capped at 390 x 844 px and centered). Touch, mouse and pen all work (Pointer Events).
- Sound uses the Web Audio API and only starts after the first touch (browser autoplay rule).

## What the study does

A grayscale pompom (900 fiber curves defined as bezier data) sits in the upper-middle of the stage. The user presses on it and drags it anywhere inside the stage bounds. The body trails the finger on a spring, so it feels soft and slightly delayed. On release it eases to rest at the last position with a small overshoot. The fibers swing against the direction of acceleration and keep swaying gently on their own.

## Main visual and interactive components

| Component | What it is |
|---|---|
| Stage | 390 x 844 max container, light gray `#ececec`, centered on a darker page |
| Pompom | Canvas-drawn fibers (quadratic curves) in three gray tones, with a spring-simulated tip per fiber |
| Affordance ring | Pulsing, fading ring around the pompom until the first grab |
| Reset button | Circular button, bottom center (44 px) |
| Sound toggle | Circular speaker button, top right (44 px), `aria-pressed` toggles on/off icon |

## User actions, feedback, states, transitions

**Actions**
- Press on the pompom (within about 0.9 x its radius) to grab it. The grab keeps your finger's offset, so it doesn't jump.
- Move while pressed to drag; the target is clamped inside the stage (and above the reset button area).
- Release to drop it where it is.
- Reset button: returns the pompom to its start position and clears motion.
- Sound button: mutes or unmutes all audio.

**States**
- Idle (not yet used): pulsing affordance ring shown.
- Dragging: ring hidden, body follows finger on a stiff spring, soft thump on grab.
- Settling (after release): body eases to the drop point on a softer spring, soft thump on release.
- Muted: gain forced to 0.

**Feedback**
- Visual: fibers lag against body acceleration and sway continuously; affordance ring until first use.
- Audio: continuous filtered-noise whoosh whose volume and brightness rise with speed; thump on grab and release.

**Transitions**
- Idle to dragging: pointerdown on the pompom.
- Dragging to settling: pointerup or pointercancel.
- Any state to idle: Reset.

## Where things are implemented (`index.html`)

| Line(s) | What |
|---|---|
| 3-15 | Styles: stage, canvas, buttons, sound on/off icon swap |
| 16-20 | Markup: `#stage`, `<canvas id="c">`, sound button `#snd`, reset button `#rst` |
| 22 | `F` fiber data (start x/y, mid control, end x/y, color, width, opacity) and `const MODE='drag'` |
| 23-31 | Setup: canvas refs, `fib` fiber objects with per-fiber spring stiffness/damping, body `B`, target `T`, state variables, `size()` and `reset()` |
| 33-45 | Audio: `initAudio()` (looping brown-noise buffer, band-pass filter, gain), `thump()` (sine drop plus noise burst) |
| 46-58 | Input: `pointerdown` grab (49-51), `pointermove` drag (52), `up` release (53-54), `clampT()` bounds (56), reset (57) and sound toggle (58) listeners |
| 60-99 | Main loop `step()` |
| 67-68 | Core drag physics: spring from body to target `T` (stiff while dragging, soft after release) |
| 75-82 | Body acceleration and per-fiber spring simulation (lag, sway) |
| 83-84 | Audio level and filter follow speed |
| 85-99 | Drawing: background, affordance ring (92), fibers |
| 100 | Start: `size(); requestAnimationFrame(step)` |

## Notes for combining studies

- This file is identical to the Flick study except for `<title>` and `const MODE='drag'` (line 22). `MODE` is a switch shared across Hold, Drag and Flick. Branches for `'hold'` (lines 31, 50, 62-65, 88) and `'flick'` (lines 67-74) are present but inactive here.
- If you merge the studies, the three are close to one engine with different input handling; consider a single shared file with a mode per step rather than three copies.
- All state is global variables; no storage, network, or external assets are used.
- Useful hooks for chaining: `reset()` (entry state), `up()` (release event), `stageN` (stage counter used by the Hold variant).
- Visual tokens are the CSS variables on line 4 (`--page`, `--stage`, `--ink`, `--chip`).

## External dependencies and assets

None. No scripts, fonts, images, or network requests. Browser APIs used: Canvas 2D, Pointer Events, Web Audio.
